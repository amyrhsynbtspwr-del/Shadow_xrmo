"use client";

import { useEffect, useMemo, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

type Profile = { id: string; username: string; display_name: string | null; bio: string | null; avatar_url: string | null; };
type Post = { id: string; user_id: string; caption: string | null; media_url: string; media_type: string; created_at: string; profiles?: Profile; likes?: { user_id: string }[]; };
type Comment = { id: string; content: string; user_id: string; profiles?: Profile; };

const fa = {
  brand: 'SHADOW-XRMO', tagline: 'دنیای تو، محتوای تو', login: 'ورود', signup: 'ساخت حساب',
  email: 'ایمیل', password: 'رمز عبور', username: 'نام کاربری', display: 'نام نمایشی',
  feed: 'خانه', explore: 'اکسپلور', profile: 'پروفایل من', create: 'پست جدید',
  caption: 'برای پستت چیزی بنویس...', choose: 'انتخاب عکس یا ویدیو', publish: 'انتشار',
  logout: 'خروج', like: 'پسندیدن', unlike: 'لغو پسند', comment: 'نظر', send: 'ارسال',
  follow: 'دنبال کردن', following: 'دنبال می‌کنی', save: 'ذخیره پروفایل',
  bio: 'درباره من', noPosts: 'هنوز پستی منتشر نشده است.', config: 'اتصال سرویس آنلاین کامل نشده است.',
  setup: 'برای فعال‌سازی، فایل راهنما را ببین و کلیدهای Supabase را تنظیم کن.',
  account: 'حساب کاربری', search: 'جست‌وجوی کاربران', loading: 'در حال بارگذاری...',
  private: 'این حساب خصوصی است', uploadErr: 'بارگذاری ناموفق بود. تنظیمات Storage را بررسی کن.',
};
const en = {
  brand: 'SHADOW-XRMO', tagline: 'Your world. Your content.', login: 'Log in', signup: 'Create account',
  email: 'Email', password: 'Password', username: 'Username', display: 'Display name',
  feed: 'Home', explore: 'Explore', profile: 'My profile', create: 'New post',
  caption: 'Write a caption...', choose: 'Choose photo or video', publish: 'Publish',
  logout: 'Log out', like: 'Like', unlike: 'Unlike', comment: 'Comment', send: 'Send',
  follow: 'Follow', following: 'Following', save: 'Save profile',
  bio: 'Bio', noPosts: 'No posts yet.', config: 'Online service is not configured.',
  setup: 'Set up Supabase keys by following the included README.',
  account: 'Account', search: 'Search users', loading: 'Loading...',
  private: 'This account is private', uploadErr: 'Upload failed. Check Storage settings.',
};

export default function SocialApp() {
  const [lang, setLang] = useState<'fa'|'en'>('fa');
  const [user, setUser] = useState<User|null>(null);
  const [profile, setProfile] = useState<Profile|null>(null);
  const [page, setPage] = useState<'feed'|'explore'|'profile'>('feed');
  const [posts, setPosts] = useState<Post[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [caption, setCaption] = useState('');
  const [file, setFile] = useState<File|null>(null);
  const [authMode, setAuthMode] = useState<'login'|'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [commentText, setCommentText] = useState<Record<string,string>>({});
  const [comments, setComments] = useState<Record<string,Comment[]>>({});
  const [editBio, setEditBio] = useState('');
  const [editDisplay, setEditDisplay] = useState('');
  const t = lang === 'fa' ? fa : en;
  const rtl = lang === 'fa';

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user && supabase) loadAccount();
    else { setProfile(null); setPosts([]); }
  }, [user]);

  async function loadAccount() {
    if (!supabase || !user) return;
    const { data } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
    if (data) { setProfile(data); setEditBio(data.bio || ''); setEditDisplay(data.display_name || ''); }
    await loadPosts();
  }
  async function loadPosts() {
    if (!supabase) return;
    const { data, error } = await supabase.from('posts').select('*, profiles(id,username,display_name,avatar_url), likes(user_id)').order('created_at', { ascending: false }).limit(80);
    if (!error) setPosts((data || []) as Post[]);
  }
  async function loadExplore() {
    if (!supabase) return;
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(60);
    setProfiles((data || []) as Profile[]);
  }
  async function signIn(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage('');
    const result = authMode === 'login'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { data: { username, display_name: displayName || username } } });
    setBusy(false);
    if (result.error) setMessage(result.error.message);
    else if (authMode === 'signup') setMessage(rtl ? 'حساب ساخته شد. اگر تأیید ایمیل فعال است، ایمیلت را بررسی کن.' : 'Account created. Check your email if confirmation is enabled.');
  }
  async function publish() {
    if (!supabase || !user || !file) { setMessage(rtl ? 'ابتدا یک عکس یا ویدیو انتخاب کن.' : 'Choose a photo or video first.'); return; }
    if (file.size > 100 * 1024 * 1024) { setMessage('Maximum file size is 100 MB.'); return; }
    setBusy(true); setMessage('');
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const path = `${user.id}/${crypto.randomUUID()}-${safeName}`;
    const upload = await supabase.storage.from('media').upload(path, file, { upsert: false });
    if (upload.error) { setBusy(false); setMessage(t.uploadErr + ' ' + upload.error.message); return; }
    const { data: urlData } = supabase.storage.from('media').getPublicUrl(path);
    const inserted = await supabase.from('posts').insert({ user_id: user.id, caption, media_url: urlData.publicUrl, media_path: path, media_type: file.type });
    setBusy(false);
    if (inserted.error) setMessage(inserted.error.message);
    else { setCaption(''); setFile(null); await loadPosts(); setMessage(rtl ? 'پست منتشر شد.' : 'Post published.'); }
  }
  async function toggleLike(post: Post) {
    if (!supabase || !user) return;
    const liked = post.likes?.some(x => x.user_id === user.id);
    if (liked) await supabase.from('likes').delete().eq('post_id', post.id).eq('user_id', user.id);
    else await supabase.from('likes').insert({ post_id: post.id, user_id: user.id });
    await loadPosts();
  }
  async function sendComment(postId: string) {
    if (!supabase || !user || !commentText[postId]?.trim()) return;
    const { error } = await supabase.from('comments').insert({ post_id: postId, user_id: user.id, content: commentText[postId].trim() });
    if (error) setMessage(error.message);
    else { setCommentText(v => ({...v,[postId]:''})); await loadComments(postId); }
  }
  async function loadComments(postId: string) {
    if (!supabase) return;
    const { data } = await supabase.from('comments').select('*, profiles(id,username,display_name)').eq('post_id', postId).order('created_at');
    setComments(v => ({...v,[postId]:(data || []) as Comment[]}));
  }
  async function toggleFollow(targetId: string) {
    if (!supabase || !user) return;
    const { data } = await supabase.from('follows').select('follower_id').eq('follower_id', user.id).eq('following_id', targetId).maybeSingle();
    if (data) await supabase.from('follows').delete().eq('follower_id', user.id).eq('following_id', targetId);
    else await supabase.from('follows').insert({ follower_id: user.id, following_id: targetId });
    await loadExplore();
  }
  async function saveProfile() {
    if (!supabase || !user) return;
    const { error } = await supabase.from('profiles').update({ display_name: editDisplay, bio: editBio }).eq('id', user.id);
    setMessage(error?.message || (rtl ? 'پروفایل ذخیره شد.' : 'Profile saved.'));
    await loadAccount();
  }
  async function removePost(post: Post) {
    if (!supabase || !user || post.user_id !== user.id || !confirm(rtl ? 'این پست حذف شود؟' : 'Delete this post?')) return;
    await supabase.storage.from('media').remove([`${post.user_id}/${post.id}`]).catch(()=>null);
    await supabase.from('posts').delete().eq('id', post.id);
    await loadPosts();
  }

  const visiblePosts = useMemo(() => page === 'profile' && user ? posts.filter(p => p.user_id === user.id) : posts, [page, posts, user]);

  if (!supabase) return <main className="setup" dir={rtl?'rtl':'ltr'}><h1>SHADOW-XRMO</h1><h2>{t.config}</h2><p>{t.setup}</p><code>NEXT_PUBLIC_SUPABASE_URL</code><code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code><button onClick={()=>setLang(lang==='fa'?'en':'fa')}>FA / EN</button></main>;

  return <main className="shell" dir={rtl?'rtl':'ltr'}>
    <header className="topbar"><a className="wordmark" onClick={()=>setPage('feed')}>SHADOW<span>-XRMO</span></a><div className="top-actions"><button className="ghost" onClick={()=>setLang(lang==='fa'?'en':'fa')}>{lang==='fa'?'EN':'FA'}</button>{user && <button className="ghost" onClick={()=>supabase.auth.signOut()}>{t.logout}</button>}</div></header>
    {!user ? <section className="auth-card">
      <div className="brand-mark">SX</div><h1>{t.brand}</h1><p className="muted">{t.tagline}</p>
      <form onSubmit={signIn}>
        {authMode==='signup' && <><label>{t.username}</label><input required minLength={3} value={username} onChange={e=>setUsername(e.target.value)} placeholder="shadow_user"/><label>{t.display}</label><input value={displayName} onChange={e=>setDisplayName(e.target.value)}/></>}
        <label>{t.email}</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/>
        <label>{t.password}</label><input type="password" required minLength={8} value={password} onChange={e=>setPassword(e.target.value)}/>
        <button className="primary full" disabled={busy}>{busy?'…':authMode==='login'?t.login:t.signup}</button>
      </form>
      <button className="text-button" onClick={()=>setAuthMode(authMode==='login'?'signup':'login')}>{authMode==='login'?t.signup:t.login}</button>
      {message && <p className="notice">{message}</p>}
    </section> : <div className="layout">
      <aside className="sidebar">
        <button className={page==='feed'?'nav active':'nav'} onClick={()=>setPage('feed')}>⌂ {t.feed}</button>
        <button className={page==='explore'?'nav active':'nav'} onClick={()=>{setPage('explore');loadExplore()}}>⌕ {t.explore}</button>
        <button className={page==='profile'?'nav active':'nav'} onClick={()=>setPage('profile')}>◉ {t.profile}</button>
        <div className="side-profile"><div className="avatar">{(profile?.username||'S')[0]?.toUpperCase()}</div><div><b>{profile?.display_name||profile?.username||'...'}</b><small>@{profile?.username}</small></div></div>
      </aside>
      <section className="content">
        {page==='explore' ? <><h2>{t.explore}</h2><div className="people-grid">{profiles.filter(p=>p.id!==user.id).map(p=><Person key={p.id} p={p} me={user.id} onFollow={()=>toggleFollow(p.id)} t={t}/>)}</div></> :
        page==='profile' ? <><section className="profile-card"><div className="avatar big">{(profile?.username||'S')[0]?.toUpperCase()}</div><div><h2>{profile?.display_name||profile?.username}</h2><p className="muted">@{profile?.username}</p><p>{profile?.bio}</p><small>{visiblePosts.length} posts</small></div></section><div className="edit-profile"><h3>{t.profile}</h3><label>{t.display}</label><input value={editDisplay} onChange={e=>setEditDisplay(e.target.value)}/><label>{t.bio}</label><textarea value={editBio} onChange={e=>setEditBio(e.target.value)}/><button className="primary" onClick={saveProfile}>{t.save}</button></div><div className="feed">{visiblePosts.map(p=><PostCard key={p.id} p={p} user={user} t={t} onLike={()=>toggleLike(p)} onComment={sendComment} onLoadComments={loadComments} commentText={commentText} setCommentText={setCommentText} comments={comments} onDelete={()=>removePost(p)}/>)}</div></> :
        <><section className="composer"><h2>{t.create}</h2><textarea value={caption} onChange={e=>setCaption(e.target.value)} placeholder={t.caption}/><label className="upload">{file?file.name:`＋ ${t.choose}`}<input type="file" accept="image/*,video/*" onChange={e=>setFile(e.target.files?.[0]||null)}/></label><button className="primary" disabled={busy||!file} onClick={publish}>{busy?'…':t.publish}</button></section><div className="feed">{posts.map(p=><PostCard key={p.id} p={p} user={user} t={t} onLike={()=>toggleLike(p)} onComment={sendComment} onLoadComments={loadComments} commentText={commentText} setCommentText={setCommentText} comments={comments} onDelete={()=>removePost(p)}/>)}</div></>}
      </section>
    </div>}
    {message && user && <div className="toast">{message}<button onClick={()=>setMessage('')}>×</button></div>}
    <footer>© {new Date().getFullYear()} SHADOW-XRMO · Built for creators</footer>
  </main>;
}

function Person({p,me,onFollow,t}:any) {
  const [following,setFollowing]=useState(false);
  useEffect(()=>{if(!supabase)return;supabase.from('follows').select('follower_id').eq('follower_id',me).eq('following_id',p.id).maybeSingle().then(({data})=>setFollowing(!!data))},[me,p.id]);
  return <article className="person"><div className="avatar">{(p.username||'?')[0].toUpperCase()}</div><b>{p.display_name||p.username}</b><small>@{p.username}</small><button className="primary" onClick={async()=>{await onFollow();setFollowing(!following)}}>{following?t.following:t.follow}</button></article>;
}
function PostCard({p,user,t,onLike,onComment,onLoadComments,commentText,setCommentText,comments,onDelete}:any) {
  const liked=p.likes?.some((x:any)=>x.user_id===user.id);
  return <article className="post-card"><div className="post-author"><div className="avatar">{(p.profiles?.username||'S')[0].toUpperCase()}</div><div><b>{p.profiles?.display_name||p.profiles?.username||'shadow user'}</b><small>@{p.profiles?.username}</small></div><time>{new Date(p.created_at).toLocaleDateString()}</time></div>
    {p.caption && <p className="caption">{p.caption}</p>}
    {p.media_type?.startsWith('video/')?<video className="post-media" src={p.media_url} controls playsInline/>:<img className="post-media" src={p.media_url} alt="Post media"/>}
    <div className="post-actions"><button onClick={onLike}>{liked?'♥':'♡'} {p.likes?.length||0} · {liked?t.unlike:t.like}</button><button onClick={()=>onLoadComments(p.id)}>▤ {t.comment}</button>{p.user_id===user.id&&<button className="delete" onClick={onDelete}>×</button>}</div>
    <div className="comments">{(comments[p.id]||[]).map((c:any)=><p key={c.id}><b>@{c.profiles?.username||'user'}</b> {c.content}</p>)}<div className="comment-form"><input value={commentText[p.id]||''} onChange={e=>setCommentText((v:any)=>({...v,[p.id]:e.target.value}))} placeholder={t.comment+'…'}/><button onClick={()=>onComment(p.id)}>{t.send}</button></div></div>
  </article>;
}
