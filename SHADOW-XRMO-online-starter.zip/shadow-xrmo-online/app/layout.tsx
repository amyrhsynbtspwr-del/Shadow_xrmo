import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SHADOW-XRMO',
  description: 'A social space for photos, videos and creators.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fa"><body>{children}</body></html>;
}
